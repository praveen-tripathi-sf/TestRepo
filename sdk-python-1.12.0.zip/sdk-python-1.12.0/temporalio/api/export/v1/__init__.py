from .message_pb2 import WorkflowExecution, WorkflowExecutions

__all__ = [
    "WorkflowExecution",
    "WorkflowExecutions",
]
