from .message_pb2 import Message

__all__ = [
    "Message",
]
