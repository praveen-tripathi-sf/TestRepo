# TODO: Change back to "default" after next CLI release
DEV_SERVER_DOWNLOAD_VERSION = "v1.3.1-persistence-fix.0"
