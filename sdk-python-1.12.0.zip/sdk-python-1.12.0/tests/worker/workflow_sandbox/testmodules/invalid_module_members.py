def invalid_function():
    return "oh no"
