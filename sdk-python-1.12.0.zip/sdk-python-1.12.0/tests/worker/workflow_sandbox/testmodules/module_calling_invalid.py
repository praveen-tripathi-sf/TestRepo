import random

random.choice(["foo", "bar"])
