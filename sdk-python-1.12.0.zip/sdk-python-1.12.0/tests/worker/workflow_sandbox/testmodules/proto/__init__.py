from .proto_message_pb2 import SomeMessage

__all__ = [
    "SomeMessage",
]
